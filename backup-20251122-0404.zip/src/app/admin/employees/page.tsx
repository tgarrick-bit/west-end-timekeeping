'use client';

import { useState, useEffect } from 'react';
import Image from 'next/image';
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs';
import { useRouter } from 'next/navigation';
import {
  Users,
  Plus,
  Search,
  Edit,
  Trash2,
  X,
  UserCheck,
  Building2,
  ChevronLeft,
} from 'lucide-react';

const US_STATES = [
  { value: 'AL', label: 'Alabama' },
  { value: 'AK', label: 'Alaska' },
  { value: 'AZ', label: 'Arizona' },
  { value: 'AR', label: 'Arkansas' },
  { value: 'CA', label: 'California' },
  { value: 'CO', label: 'Colorado' },
  { value: 'CT', label: 'Connecticut' },
  { value: 'DE', label: 'Delaware' },
  { value: 'FL', label: 'Florida' },
  { value: 'GA', label: 'Georgia' },
  { value: 'HI', label: 'Hawaii' },
  { value: 'ID', label: 'Idaho' },
  { value: 'IL', label: 'Illinois' },
  { value: 'IN', label: 'Indiana' },
  { value: 'IA', label: 'Iowa' },
  { value: 'KS', label: 'Kansas' },
  { value: 'KY', label: 'Kentucky' },
  { value: 'LA', label: 'Louisiana' },
  { value: 'ME', label: 'Maine' },
  { value: 'MD', label: 'Maryland' },
  { value: 'MA', label: 'Massachusetts' },
  { value: 'MI', label: 'Michigan' },
  { value: 'MN', label: 'Minnesota' },
  { value: 'MS', label: 'Mississippi' },
  { value: 'MO', label: 'Missouri' },
  { value: 'MT', label: 'Montana' },
  { value: 'NE', label: 'Nebraska' },
  { value: 'NV', label: 'Nevada' },
  { value: 'NH', label: 'New Hampshire' },
  { value: 'NJ', label: 'New Jersey' },
  { value: 'NM', label: 'New Mexico' },
  { value: 'NY', label: 'New York' },
  { value: 'NC', label: 'North Carolina' },
  { value: 'ND', label: 'North Dakota' },
  { value: 'OH', label: 'Ohio' },
  { value: 'OK', label: 'Oklahoma' },
  { value: 'OR', label: 'Oregon' },
  { value: 'PA', label: 'Pennsylvania' },
  { value: 'RI', label: 'Rhode Island' },
  { value: 'SC', label: 'South Carolina' },
  { value: 'SD', label: 'South Dakota' },
  { value: 'TN', label: 'Tennessee' },
  { value: 'TX', label: 'Texas' },
  { value: 'UT', label: 'Utah' },
  { value: 'VT', label: 'Vermont' },
  { value: 'VA', label: 'Virginia' },
  { value: 'WA', label: 'Washington' },
  { value: 'WV', label: 'West Virginia' },
  { value: 'WI', label: 'Wisconsin' },
  { value: 'WY', label: 'Wyoming' },
];

// Consistent name format helper: "Last, First Middle" by default
function formatName(
  first?: string,
  middle?: string,
  last?: string,
  style: 'lastFirst' | 'firstLast' = 'lastFirst'
) {
  const safeFirst = first?.trim() || '';
  const safeMiddle = middle?.trim() || '';
  const safeLast = last?.trim() || '';

  if (style === 'firstLast') {
    // "First Middle Last"
    return [safeFirst, safeMiddle, safeLast].filter(Boolean).join(' ');
  }

  // Default: "Last, First Middle"
  const firstPart = [safeFirst, safeMiddle].filter(Boolean).join(' ');
  if (!safeLast) return firstPart || '';
  if (!firstPart) return safeLast;
  return `${safeLast}, ${firstPart}`;
}

interface Employee {
  id: string;
  first_name: string;
  middle_name?: string;
  last_name: string;
  email: string;
  phone?: string;
  role: string;
  department?: string;
  hire_date?: string;
  hourly_rate?: number;
  bill_rate?: number | null;
  is_active: boolean;
  is_exempt: boolean;
  state?: string;
  employee_id?: string;
  client_id?: string;
  manager_id?: string;
  mybase_payroll_id?: string;
}

interface Manager {
  id: string;
  first_name: string;
  middle_name?: string;
  last_name: string;
  department?: string;
}

type RoleFilter = 'all' | 'employee' | 'manager' | 'admin';

export default function EmployeeManagement() {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [managers, setManagers] = useState<Manager[]>([]);
  const [filteredEmployees, setFilteredEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [success, setSuccess] = useState<string | null>(null);

  const [roleFilter, setRoleFilter] = useState<RoleFilter>('all');
  const [managerFilter, setManagerFilter] = useState<string>('all');

  const supabase = createClientComponentClient();
  const router = useRouter();

  const [formData, setFormData] = useState({
    first_name: '',
    middle_name: '',
    last_name: '',
    email: '',
    phone: '',
    role: 'employee', // 'employee' | 'manager' | 'admin'
    department: '',
    hire_date: new Date().toISOString().split('T')[0],
    hourly_rate: 0,
    bill_rate: 0,
    is_active: true,
    is_exempt: false,
    state: 'CA',
    employee_id: '',
    mybase_payroll_id: '',
    manager_id: '',
    password: '',
  });

  useEffect(() => {
    checkAuthAndFetch();
  }, []);

  useEffect(() => {
    filterEmployees();
  }, [employees, searchTerm, roleFilter, managerFilter]);

  const checkAuthAndFetch = async () => {
    try {
      const {
        data: { user },
        error: authError,
      } = await supabase.auth.getUser();

      if (authError || !user) {
        router.push('/auth/login');
        return;
      }

      const { data: userData } = await supabase
        .from('employees')
        .select('role')
        .eq('id', user.id)
        .single();

      if (userData?.role !== 'admin') {
        router.push('/dashboard');
        return;
      }

      await fetchEmployees();
      await fetchManagers();
    } catch (err) {
      console.error('Error:', err);
      setError('Failed to load data');
      setLoading(false);
    }
  };

  const fetchEmployees = async () => {
    try {
      const { data, error } = await supabase
        .from('employees')
        .select('*')
        .order('last_name', { ascending: true });

      if (error) throw error;

      setEmployees(data || []);
    } catch (error) {
      console.error('Error fetching employees:', error);
      setError('Failed to load employees');
    } finally {
      setLoading(false);
    }
  };

  const fetchManagers = async () => {
    try {
      const { data, error } = await supabase
        .from('employees')
        .select('id, first_name, middle_name, last_name, department')
        .in('role', ['manager', 'admin', 'time_approver'])
        .eq('is_active', true)
        .order('last_name');

      if (error) throw error;
      setManagers(data || []);
    } catch (error) {
      console.error('Error fetching managers:', error);
    }
  };

  const filterEmployees = () => {
    let filtered = [...employees];

    // Search
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(
        (emp) =>
          emp.first_name?.toLowerCase().includes(term) ||
          emp.middle_name?.toLowerCase().includes(term) ||
          emp.last_name?.toLowerCase().includes(term) ||
          emp.email?.toLowerCase().includes(term) ||
          emp.employee_id?.toLowerCase().includes(term)
      );
    }

    // Role filter
    if (roleFilter !== 'all') {
      filtered = filtered.filter((emp) => emp.role === roleFilter);
    }

    // Manager filter – when a manager is selected, show only employees reporting to them
    if (managerFilter !== 'all') {
      filtered = filtered.filter(
        (emp) =>
          emp.role === 'employee' && emp.manager_id === managerFilter
      );
    }

    // Always sort alphabetically by last, then first, then middle
    filtered.sort((a, b) => {
      const aLast = a.last_name || '';
      const bLast = b.last_name || '';
      const lastCmp = aLast.localeCompare(bLast);
      if (lastCmp !== 0) return lastCmp;

      const aFirst = a.first_name || '';
      const bFirst = b.first_name || '';
      const firstCmp = aFirst.localeCompare(bFirst);
      if (firstCmp !== 0) return firstCmp;

      const aMiddle = a.middle_name || '';
      const bMiddle = b.middle_name || '';
      return aMiddle.localeCompare(bMiddle);
    });

    setFilteredEmployees(filtered);
  };

  // Create employee via API
  const handleAddEmployee = async () => {
    setIsCreating(true);
    setError(null);
    setSuccess(null);

    try {
      const isEmployee = formData.role === 'employee';

      // Basic required fields
      if (
        !formData.email ||
        !formData.first_name ||
        !formData.last_name ||
        !formData.password ||
        (isEmployee && !formData.manager_id)
      ) {
        let message = 'Please fill in all required fields.';

        if (isEmployee && !formData.manager_id) {
          message =
            'Please fill in all required fields, including Time Approver, for employees.';
        }

        setError(message);
        setIsCreating(false);
        return;
      }

      if (formData.password.length < 6) {
        setError('Password must be at least 6 characters');
        setIsCreating(false);
        return;
      }

      const response = await fetch('/api/admin/employees', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: formData.email,
          password: formData.password,
          firstName: formData.first_name,
          middleName: formData.middle_name || null,
          lastName: formData.last_name,
          role: formData.role || 'employee',
          department: formData.department || null,
          managerId: isEmployee ? formData.manager_id : null,
          hourlyRate: isEmployee ? formData.hourly_rate || null : null,
          billRate: isEmployee ? formData.bill_rate || null : null,
          employeeId: formData.employee_id || null,
          mybasePayrollId: formData.mybase_payroll_id,
          hireDate: formData.hire_date || null,
          state: formData.state || null,
          isActive: formData.is_active,
          isExempt: formData.is_exempt,
        }),
      });

      const data = await response.json();
      console.log('API Response:', data);

      if (!response.ok) {
        throw new Error(data.error || 'Failed to create employee');
      }

      setSuccess(
        `Employee "${formatName(
          formData.first_name,
          formData.middle_name,
          formData.last_name
        )}" created successfully!`
      );

      await fetchEmployees();

      setTimeout(() => {
        setShowAddModal(false);
        resetForm();
        setSuccess(null);
      }, 3000);
    } catch (error: any) {
      console.error('Error adding employee:', error);
      setError(error?.message || 'Failed to create employee');
    } finally {
      setIsCreating(false);
    }
  };

  const handleUpdateEmployee = async () => {
    if (!selectedEmployee) return;

    try {
      const updateData: any = { ...formData };
      delete updateData.password;

      // Only keep pay rates and manager for employees
      if (formData.role !== 'employee') {
        updateData.hourly_rate = null;
        updateData.bill_rate = null;
        updateData.manager_id = null;
      }

      const { error } = await supabase
        .from('employees')
        .update(updateData)
        .eq('id', selectedEmployee.id);

      if (error) throw error;

      setShowEditModal(false);
      setSelectedEmployee(null);
      resetForm();
      fetchEmployees();
    } catch (error: any) {
      console.error('Error updating employee:', error);
      alert(`Error: ${error.message}`);
    }
  };

  const handleDeactivateEmployee = async (id: string) => {
    if (!confirm('Are you sure you want to deactivate this employee?')) return;

    try {
      const { error } = await supabase
        .from('employees')
        .update({ is_active: false })
        .eq('id', id);

      if (error) throw error;
      fetchEmployees();
    } catch (error) {
      console.error('Error deactivating employee:', error);
    }
  };

  const openEditModal = (employee: Employee) => {
    setSelectedEmployee(employee);
    setFormData({
      first_name: employee.first_name || '',
      middle_name: employee.middle_name || '',
      last_name: employee.last_name || '',
      email: employee.email || '',
      phone: employee.phone || '',
      role: employee.role || 'employee',
      department: employee.department || '',
      hire_date: employee.hire_date || '',
      hourly_rate: employee.hourly_rate || 0,
      bill_rate: employee.bill_rate || 0,
      is_active: employee.is_active !== false,
      is_exempt: employee.is_exempt || false,
      state: employee.state || 'CA',
      employee_id: employee.employee_id || '',
      mybase_payroll_id: employee.mybase_payroll_id || '',
      manager_id: employee.manager_id || '',
      password: '',
    });
    setShowEditModal(true);
  };

  const resetForm = () => {
    setFormData({
      first_name: '',
      middle_name: '',
      last_name: '',
      email: '',
      phone: '',
      role: 'employee',
      department: '',
      hire_date: new Date().toISOString().split('T')[0],
      hourly_rate: 0,
      bill_rate: 0,
      is_active: true,
      is_exempt: false,
      state: 'CA',
      employee_id: '',
      mybase_payroll_id: '',
      manager_id: '',
      password: '',
    });
  };

  const getManagerName = (employee: Employee) => {
    if (!employee.manager_id) return '—';
    const manager = managers.find((m) => m.id === employee.manager_id);
    if (!manager) return '—';
    return formatName(manager.first_name, manager.middle_name, manager.last_name);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#e31c79] mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading employees...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header (match other admin pages) */}
      <header className="bg-[#05202E] shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Left section: Back button + Logo + Title */}
            <div className="flex items-center gap-4">
              {/* Back arrow */}
              <button
                onClick={() => router.push('/admin')}
                className="p-2 hover:bg-white/10 rounded-lg transition-colors text-gray-200 hover:text-white"
              >
                <ChevronLeft className="h-5 w-5" />
              </button>

              {/* Logo */}
              <Image
                src="/WE-logo-SEPT2024v3-WHT.png"
                alt="West End Workforce"
                width={180}
                height={40}
                className="h-9 w-auto"
                priority
              />

              {/* Portal title */}
              <div className="border-l border-gray-600 pl-3">
                <p className="text-xs text-gray-300 uppercase tracking-wide">
                  Admin Portal
                </p>
                <p className="text-sm text-gray-100">
                  Employee Management
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Actions Bar */}
        <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            {/* Left side: search */}
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search employees..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#e31c79] focus:border-[#e31c79]"
              />
            </div>

            {/* Right side: button */}
            <button
              onClick={() => setShowAddModal(true)}
              className="px-4 py-2 bg-[#e31c79] text-white rounded-lg hover:bg-[#c91865] flex items-center gap-2 self-start md:self-auto"
            >
              <Plus className="h-4 w-4" />
              Add Employee
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white rounded-lg shadow-sm p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Employees</p>
                <p className="text-2xl font-bold text-gray-900">
                  {employees.length}
                </p>
              </div>
              <Users className="h-8 w-8 text-gray-400" />
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-sm p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Active</p>
                <p className="text-2xl font-bold text-green-600">
                  {employees.filter((e) => e.is_active).length}
                </p>
              </div>
              <UserCheck className="h-8 w-8 text-green-500" />
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-sm p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Managers</p>
                <p className="text-2xl font-bold text-blue-600">
                  {employees.filter((e) => e.role === 'manager').length}
                </p>
              </div>
              <Building2 className="h-8 w-8 text-blue-500" />
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-sm p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Admins</p>
                <p className="text-2xl font-bold text-purple-600">
                  {employees.filter((e) => e.role === 'admin').length}
                </p>
              </div>
              <UserCheck className="h-8 w-8 text-purple-500" />
            </div>
          </div>
        </div>

        {/* Employee Table */}
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <table className="min-w-full">
            <thead>
              {/* Main header row */}
              <tr className="bg-[#05202E] text-white">
                <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">
                  Employee
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">
                  Contact
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">
                  Role
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">
                  Manager
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">
                  Actions
                </th>
              </tr>

              {/* Filter row */}
              <tr className="bg-gray-50 text-gray-700 text-xs">
                {/* Employee column – no filter here */}
                <th className="px-6 py-2" />

                {/* Contact column – no filter here */}
                <th className="px-6 py-2" />

                {/* Role filter */}
                <th className="px-6 py-2">
                  <select
                    value={roleFilter}
                    onChange={(e) =>
                      setRoleFilter(e.target.value as RoleFilter)
                    }
                    className="w-full text-xs px-2 py-1 border border-gray-300 rounded-md bg-white focus:outline-none focus:ring-[#e31c79]"
                  >
                    <option value="all">All</option>
                    <option value="employee">Employees</option>
                    <option value="manager">Managers</option>
                    <option value="admin">Admins</option>
                  </select>
                </th>

                {/* Manager filter */}
                <th className="px-6 py-2">
                  <select
                    value={managerFilter}
                    onChange={(e) => setManagerFilter(e.target.value)}
                    className="w-full text-xs px-2 py-1 border border-gray-300 rounded-md bg-white focus:outline-none focus:ring-[#e31c79]"
                  >
                    <option value="all">All</option>
                    {managers.map((m) => (
                      <option key={m.id} value={m.id}>
                        {formatName(m.first_name, m.middle_name, m.last_name)}
                      </option>
                    ))}
                  </select>
                </th>

                {/* Status & Actions – no filters */}
                <th className="px-6 py-2" />
                <th className="px-6 py-2" />
              </tr>
            </thead>

            <tbody className="bg-white divide-y divide-gray-200">
              {filteredEmployees.map((employee) => (
                <tr key={employee.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900">
                        {formatName(
                          employee.first_name,
                          employee.middle_name,
                          employee.last_name
                        )}
                      </div>
                      <div className="text-sm text-gray-500">
                        {employee.mybase_payroll_id ||
                          employee.employee_id ||
                          'No ID'}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">
                      {employee.email}
                    </div>
                    <div className="text-sm text-gray-500">
                      {employee.phone || 'No phone'}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span
                      className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full
                      ${
                        employee.role === 'admin'
                          ? 'bg-purple-100 text-purple-800'
                          : employee.role === 'manager'
                          ? 'bg-blue-100 text-blue-800'
                          : employee.role === 'time_approver'
                          ? 'bg-orange-100 text-orange-800'
                          : 'bg-gray-100 text-gray-800'
                      }`}
                    >
                      {employee.role}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-sm text-gray-700">
                      {getManagerName(employee)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span
                      className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full
                      ${
                        employee.is_active
                          ? 'bg-green-100 text-green-800'
                          : 'bg-red-100 text-red-800'
                      }`}
                    >
                      {employee.is_active ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button
                      onClick={() => openEditModal(employee)}
                      className="text-[#e31c79] hover:text-[#c91865] mr-3"
                    >
                      <Edit className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() =>
                        handleDeactivateEmployee(employee.id)
                      }
                      className="text-red-600 hover:text-red-900"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>

      {/* Add/Edit Modal */}
      {(showAddModal || showEditModal) && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold text-gray-900">
                  {showAddModal ? 'Add New Employee' : 'Edit Employee'}
                </h2>
                <button
                  onClick={() => {
                    setShowAddModal(false);
                    setShowEditModal(false);
                    resetForm();
                  }}
                  className="p-2 hover:bg-gray-100 rounded-lg"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
            </div>

            <div className="p-6">
              {(error || success) && (
                <div className="mb-4">
                  {error && (
                    <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-2 rounded-md text-sm">
                      {error}
                    </div>
                  )}
                  {success && (
                    <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-2 rounded-md text-sm">
                      {success}
                    </div>
                  )}
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                {/* First / Middle / Last Name */}
                <div className="col-span-2 grid grid-cols-1 md:grid-cols-3 gap-4">
                  {/* First Name */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      First Name *
                    </label>
                    <input
                      type="text"
                      value={formData.first_name}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          first_name: e.target.value,
                        })
                      }
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#e31c79]"
                    />
                  </div>

                  {/* Middle Name */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Middle Name
                    </label>
                    <input
                      type="text"
                      value={formData.middle_name}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          middle_name: e.target.value,
                        })
                      }
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#e31c79]"
                    />
                  </div>

                  {/* Last Name */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Last Name *
                    </label>
                    <input
                      type="text"
                      value={formData.last_name}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          last_name: e.target.value,
                        })
                      }
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#e31c79]"
                    />
                  </div>
                </div>

                {/* Email */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email *
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        email: e.target.value,
                      })
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#e31c79]"
                  />
                </div>

                {/* Phone */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Phone
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        phone: e.target.value,
                      })
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#e31c79]"
                  />
                </div>

                {/* Role */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Role *
                  </label>
                  <select
                    value={formData.role}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        role: e.target.value,
                      })
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#e31c79]"
                  >
                    <option value="employee">Employee</option>
                    <option value="manager">Manager / Time Approver</option>
                    <option value="admin">Admin</option>
                  </select>
                  <p className="text-xs text-gray-500 mt-1">
                    Managers and admins do not require pay rates or IDs.
                  </p>
                </div>

                {/* Employee ID */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Employee ID
                  </label>
                  <input
                    type="text"
                    value={formData.employee_id}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        employee_id: e.target.value,
                      })
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#e31c79]"
                  />
                </div>

                {/* MyBase Payroll ID */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    MyBase Payroll ID{' '}
                    <span className="text-gray-400">(Optional)</span>
                  </label>
                  <input
                    type="text"
                    value={formData.mybase_payroll_id || ''}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        mybase_payroll_id: e.target.value,
                      })
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#e31c79]"
                    placeholder="Leave blank if not needed"
                  />
                  <p className="text-xs text-gray-600 mt-1">
                    For payroll exports (can be added later)
                  </p>
                </div>

                {/* Time Approver – ONLY for employees */}
                {formData.role === 'employee' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Time Approver <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={formData.manager_id}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          manager_id: e.target.value,
                        })
                      }
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#e31c79]"
                      required={formData.role === 'employee'}
                    >
                      <option value="">Select Time Approver</option>
                      {managers.map((manager) => (
                        <option key={manager.id} value={manager.id}>
                          {formatName(
                            manager.first_name,
                            manager.middle_name,
                            manager.last_name
                          )}
                          {manager.department ? ` - ${manager.department}` : ''}
                        </option>
                      ))}
                    </select>
                    <p className="text-xs text-gray-500 mt-1">
                      Timesheets will appear on this approver&apos;s dashboard
                    </p>
                  </div>
                )}

                {/* Hourly & Bill Rate – only for employees */}
                {formData.role === 'employee' && (
                  <>
                    {/* Hourly Rate */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Hourly Rate
                      </label>
                      <input
                        type="number"
                        step="0.01"
                        value={formData.hourly_rate}
                        onChange={(e) => {
                          const value = e.target.value;
                          setFormData({
                            ...formData,
                            hourly_rate:
                              value === '' ? 0 : parseFloat(value),
                          });
                        }}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#e31c79]"
                      />
                    </div>

                    {/* Bill Rate */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Bill Rate
                      </label>
                      <input
                        type="number"
                        step="0.01"
                        value={formData.bill_rate}
                        onChange={(e) => {
                          const value = e.target.value;
                          setFormData({
                            ...formData,
                            bill_rate:
                              value === '' ? 0 : parseFloat(value),
                          });
                        }}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#e31c79]"
                      />
                      <p className="text-xs text-gray-600 mt-1">
                        Optional. Used for billing and margin calculations.
                      </p>
                    </div>
                  </>
                )}

                {/* Hire Date */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Hire Date
                  </label>
                  <input
                    type="date"
                    value={formData.hire_date}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        hire_date: e.target.value,
                      })
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#e31c79]"
                  />
                </div>

                {/* State */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    State
                  </label>
                  <select
                    value={formData.state}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        state: e.target.value,
                      })
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#e31c79]"
                  >
                    <option value="">Select State</option>
                    {US_STATES.map((state) => (
                      <option
                        key={state.value}
                        value={state.value}
                      >
                        {state.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Temp Password (add mode only) */}
                {showAddModal && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Temporary Password *
                    </label>
                    <input
                      type="password"
                      value={formData.password}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          password: e.target.value,
                        })
                      }
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#e31c79]"
                      placeholder="Min 6 characters"
                    />
                  </div>
                )}

                {/* Status + Exempt */}
                <div className="col-span-2 flex items-center gap-6">
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={formData.is_active}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          is_active: e.target.checked,
                        })
                      }
                      className="mr-2 text-[#e31c79]"
                    />
                    <span className="text-sm text-gray-700">
                      Active
                    </span>
                  </label>
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={formData.is_exempt}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          is_exempt: e.target.checked,
                        })
                      }
                      className="mr-2 text-[#e31c79]"
                    />
                    <span className="text-sm text-gray-700">
                      Exempt (Salary)
                    </span>
                  </label>
                </div>
              </div>

              <div className="flex justify-end gap-3 mt-6">
                <button
                  onClick={() => {
                    setShowAddModal(false);
                    setShowEditModal(false);
                    resetForm();
                  }}
                  className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={
                    showAddModal
                      ? handleAddEmployee
                      : handleUpdateEmployee
                  }
                  disabled={isCreating}
                  className="px-4 py-2 bg-[#e31c79] text-white rounded-lg hover:bg-[#c91865] disabled:opacity-60"
                >
                  {showAddModal
                    ? isCreating
                      ? 'Adding...'
                      : 'Add Employee'
                    : 'Save Changes'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

