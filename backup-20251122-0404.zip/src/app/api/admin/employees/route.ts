// src/app/api/admin/employees/route.ts

import { createClient } from '@supabase/supabase-js'
import { NextRequest, NextResponse } from 'next/server'
import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'

// Create admin client with service role key for user management
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!, // Service role key for admin operations
  {
    auth: {
      autoRefreshToken: false,
      persistSession: false
    }
  }
)

export async function GET(request: NextRequest) {
  try {
    // Regular client for checking permissions
    const supabase = createRouteHandlerClient({ cookies })
    
    // Check if user is admin
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { data: currentUser } = await supabase
      .from('employees')
      .select('role')
      .eq('id', user.id)
      .single()

    if (!currentUser || currentUser.role !== 'admin') {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
    }

    // Fetch all employees
    const { data: employees, error } = await supabase
      .from('employees')
      .select('*')
      .order('last_name', { ascending: true })

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ employees })
  } catch (error) {
    console.error('Error fetching employees:', error)
    return NextResponse.json({ error: 'Failed to fetch employees' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    // Regular client for checking permissions
    const supabase = createRouteHandlerClient({ cookies })
    
    // Check if user is admin
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { data: currentUser } = await supabase
      .from('employees')
      .select('role')
      .eq('id', user.id)
      .single()

    if (!currentUser || currentUser.role !== 'admin') {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
    }

    // Get form data
    const body = await request.json()
    const {
      email,
      password,
      firstName,
      lastName,
      role,
      department,
      managerId,
      hourlyRate,
      billRate,         // NEW: from frontend
      employeeId,
      mybasePayrollId,
      hireDate,
      state,
      isActive,
      isExempt,
    } = body

    const effectiveRole = role || 'employee'
    const isEmployee = effectiveRole === 'employee'

    // ✅ Required fields: managerId only required for employees
    if (
      !email ||
      !password ||
      !firstName ||
      !lastName ||
      (isEmployee && !managerId)
    ) {
      let errorMessage = 'Please fill in all required fields.'

      if (isEmployee && !managerId) {
        errorMessage =
          'Please fill in all required fields, including Time Approver, for employees.'
      }

      return NextResponse.json(
        { error: errorMessage },
        { status: 400 }
      )
    }

    if (password.length < 6) {
      return NextResponse.json(
        { error: 'Password must be at least 6 characters.' },
        { status: 400 }
      )
    }

    // Step 1: Create auth user using admin client
    const { data: authUser, error: authError } = await supabaseAdmin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: {
        first_name: firstName,
        last_name: lastName,
        role: effectiveRole,
      },
    })

    if (authError) {
      console.error('Auth error details:', authError)
      
      if (
        authError.message?.includes('already been registered') || 
        authError.message?.includes('already exists') ||
        authError.message?.includes('duplicate')
      ) {
        return NextResponse.json({ 
          error: 'A user with this email already exists. Please use a different email.' 
        }, { status: 400 })
      }
      
      return NextResponse.json({ 
        error: `Error creating user: ${authError.message}` 
      }, { status: 400 })
    }

    if (!authUser.user) {
      return NextResponse.json({ error: 'Failed to create auth user' }, { status: 400 })
    }

    const authId = authUser.user.id

    // Step 2: Create or update employee record using the auth user's ID
    //        (upsert makes this idempotent and avoids duplicate key errors)
    const { data: employee, error: employeeError } = await supabase
      .from('employees')
      .upsert(
        {
          id: authId,
          email,
          first_name: firstName,
          last_name: lastName,
          role: effectiveRole,
          department: department || null,
          manager_id: isEmployee ? (managerId || null) : null,        // only for employees
          mybase_payroll_id: mybasePayrollId || null,
          employee_id: employeeId || null,
          hourly_rate: isEmployee ? (hourlyRate ?? null) : null,      // only for employees
          bill_rate: isEmployee ? (billRate ?? null) : null,          // only for employees
          hire_date: hireDate || null,
          state: state || null,
          is_active: isActive ?? true,
          is_exempt: isExempt ?? false,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
        { onConflict: 'id' }   // 👈 key part: if id exists, update instead of error
      )
      .select()
      .single()

    if (employeeError) {
      console.error('Employee creation error:', employeeError)

      // Cleanup auth user if employee upsert fails for some other reason
      await supabaseAdmin.auth.admin.deleteUser(authId)
      
      return NextResponse.json({ 
        error: `Database error: ${employeeError.message}` 
      }, { status: 400 })
    }

    return NextResponse.json({ 
      success: true,
      employee,
      message: 'Employee created successfully',
    })

  } catch (error) {
    console.error('Error creating employee:', error)
    return NextResponse.json({ error: 'Failed to create employee' }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies })
    
    // Check if user is admin
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { data: currentUser } = await supabase
      .from('employees')
      .select('role')
      .eq('id', user.id)
      .single()

    if (!currentUser || currentUser.role !== 'admin') {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
    }

    const { searchParams } = new URL(request.url)
    const employeeId = searchParams.get('id')
    
    if (!employeeId) {
      return NextResponse.json({ error: 'Employee ID required' }, { status: 400 })
    }

    const body = await request.json()
    
    // Update employee record
    const { data: employee, error } = await supabase
      .from('employees')
      .update({
        ...body,
        updated_at: new Date().toISOString()
      })
      .eq('id', employeeId)
      .select()
      .single()

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    // If email changed, update auth user email
    if (body.email) {
      const { error: authError } = await supabaseAdmin.auth.admin.updateUserById(
        employeeId,
        { email: body.email }
      )
      
      if (authError) {
        console.error('Failed to update auth email:', authError)
      }
    }

    return NextResponse.json({ employee })
  } catch (error) {
    console.error('Error updating employee:', error)
    return NextResponse.json({ error: 'Failed to update employee' }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies })
    
    // Check if user is admin
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { data: currentUser } = await supabase
      .from('employees')
      .select('role')
      .eq('id', user.id)
      .single()

    if (!currentUser || currentUser.role !== 'admin') {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
    }

    const { searchParams } = new URL(request.url)
    const employeeId = searchParams.get('id')
    
    if (!employeeId) {
      return NextResponse.json({ error: 'Employee ID required' }, { status: 400 })
    }

    // Delete from employees table
    const { error: deleteError } = await supabase
      .from('employees')
      .delete()
      .eq('id', employeeId)

    if (deleteError) {
      return NextResponse.json({ error: deleteError.message }, { status: 500 })
    }

    // Delete auth user
    const { error: authError } = await supabaseAdmin.auth.admin.deleteUser(employeeId)
    
    if (authError) {
      console.error('Failed to delete auth user:', authError)
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting employee:', error)
    return NextResponse.json({ error: 'Failed to delete employee' }, { status: 500 })
  }
}