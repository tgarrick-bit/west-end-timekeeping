'use client';

import WeeklyTimesheet from '../../components/WeeklyTimesheet';

export default function TimesheetPage() {
  return <WeeklyTimesheet />;
}
