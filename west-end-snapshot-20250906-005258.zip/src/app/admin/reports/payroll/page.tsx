export default function PayrollReportPage() {
  return <div>Payroll Reports - Coming Soon</div>;
}
