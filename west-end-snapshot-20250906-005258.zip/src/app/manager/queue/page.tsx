// src/app/manager/queue/page.tsx
import { redirect } from "next/navigation";

export default function Page() {
  redirect("/manager/approvals");
}
